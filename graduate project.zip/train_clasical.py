import train
import knn
import numpy as np
import torch
import nns
import utils
import dis_com

if __name__ == "__main__":
    data = utils.loadData('Car')
    print(data.shape)
    np.random.shuffle(data)
    train_x, train_y = data[0:30,0:-1], data[0:30,-1]
    test_x, test_y = data[30:-1,0:-1], data[30:,-1]

    nums = test_x.shape[0]
    real = 0

    for i in range(nums):
        predict = knn.predict(test_x[i], train_x, train_y, 1, dis_com.n2norm)
        print(predict)
        if predict == test_y[i]:
            real += 1
    
    print(real/nums)

    
