import numpy as np
import dis_com
from scipy import stats

def modefy_simple(data, label):
    [rowSize, columnSize] = data.shape

    res = np.zeros((rowSize * rowSize, 2 * columnSize + 1))
    for i in range(rowSize):
        for j in range(rowSize):
            res[i * rowSize  + j, 0:columnSize] = data[i]
            res[i * rowSize  + j, columnSize:2 * columnSize] = data[j]
            res[i * rowSize  + j, 2 * columnSize] = dis_com.ou_dis(data[i], data[j])
            if label[i] == label[j]:
                res[i * rowSize  + j, 2 * columnSize] += 5
            else:
                res[i * rowSize  + j, 2 * columnSize] -= 5

    return res

def modefy_simple_sub(data, label, zscore=True):
    [rowSize, columnSize] = data.shape

    res = np.zeros((rowSize * rowSize, columnSize + 1))
    for i in range(rowSize):
        for j in range(rowSize):
            res[i * rowSize  + j, 0:columnSize] = data[i] - data[j]
            res[i * rowSize  + j, columnSize] = sum(res[i * rowSize + j] ** 2) ** 0.5
            if label[i] == label[j]:
                res[i * rowSize  + j, columnSize] += 5
            else:
                res[i * rowSize  + j, columnSize] -= 5
    if zscore:
        res[:,-1] = stats.zscore(res[:,-1])

    return res