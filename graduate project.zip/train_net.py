from statistics import mode
import train
import knn as kn
import numpy as np
import torch
import nns
import utils
from sklearn.neighbors import KNeighborsClassifier
import dis_com

if __name__ == "__main__":
    data = utils.loadData('Car')
    np.random.shuffle(data)
    rowSize = data.shape[0]
    trainSize = rowSize // 3
    testSize = rowSize - trainSize
    train_x, train_y = data[:trainSize,0:-1], data[:trainSize,-1]
    test_x, test_y = data[trainSize:,0:-1], data[trainSize:,-1]

    knn = KNeighborsClassifier(n_neighbors=3, algorithm='kd_tree')    #实例化KNN模型
    knn.fit(train_x, train_y)
    predicts = knn.predict(test_x)

    res = np.unique((predicts == test_y), return_counts=True)
    res = res[1][1] / sum(res[1])
    #res = res[1][1]
    print(res)
    '''    #predict
    tmp = 0
    nums = testSize
    model = torch.load('model_ou.pkl')
    print(model)

    
    for i in range(nums):
        print(i)
        if kn.predict_net(test_x[i], train_x, train_y, 3, model) == test_y[i]:
            tmp += 1

    print(tmp/nums)
    '''
    #predict_sub
    tmp = 0
    nums = testSize
    model = torch.load('model_lstm2_6_ou_sub_improved.pkl')
    print(model)
    print(test_x.shape)

    for i in range(nums):
        print(i)
        if kn.predict_net_sub(test_x[i], train_x, train_y, 3, model) == test_y[i]:
            tmp += 1

    print(tmp/nums)




#0.125 0.1375 0.1375 0.1
#0.15 0.1375 0.15 0.15
