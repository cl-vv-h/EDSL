import torch
import numpy as np
import pandas as pd

dataset = ['Car', 'Earthquakes', 'ECG5000', 'UWaveGestureLibraryX']

def np2tensor(x):
    x_ = torch.from_numpy(x)
    x_ = x_.to(torch.float32)
    return x_

def loadcsv2np(set_name):
    res = np.loadtxt('.\datasets\\' + set_name + '.csv', delimiter=',')
    return res

def loadboth2np(set_name):
    train = np.loadtxt('.\datasets\\' + set_name + '_TRAIN.csv', delimiter=',')
    test = np.loadtxt('.\datasets\\' + set_name + '_TEST.csv', delimiter=',')

    return np.concatenate((train, test))

def loadData(set_name):
    if set_name in dataset:
        return loadboth2np(set_name)
    else:
        return loadcsv2np(set_name)

def clearColumn(set_name):
    return
