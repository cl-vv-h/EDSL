import train
import knn as kn
import numpy as np
import torch
import nns
import utils
import dis_com
import truth_improve

if __name__ == "__main__":
    data = utils.loadData('Car')
    np.random.shuffle(data)
    rowSize = data.shape[0]
    trainSize = rowSize // 3
    testSize = rowSize - trainSize
    train_x, train_y = data[:trainSize,0:-1], data[:trainSize,-1]
    test_x, test_y = data[trainSize:,0:-1], data[trainSize:,-1]

    train_data = truth_improve.modefy_simple_sub(data[:, :-1],data[:,-1], zscore=False)
    #train_data = train.data_build(data[:, :-1])
    print(train_data[:,-1])

    model = train.train(train_data[:,:-1], train_data[:,-1], nns.Lstm)

    torch.save(model, 'model_lstm4_6_ou_sub_improved.pkl')


